package com.example.guessinggame;

import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity {
    private EditText editText2;
    private Button btnGuess;
    private TextView lblOutput;
    private int theNumber;

    public void checkGuess() {
        String guessText = editText2.getText().toString();
        String message = "";

        try {
            int guess = Integer.parseInt(guessText);
            if (guess < theNumber)
                message = "Boooo! Your guess (" + guess + ") is too low. Try again :/";
            else if (guess > theNumber)
                message = "Boooo! Your guess (" + guess + ") is too high. Try again :/";
            else {
                message = "Wohooo! You are super duper! Type a new number to play again!";
                newGame();
            }

        } catch (Exception e) {
            message = "Enter a number between 1 and 100.";
        } finally {
            lblOutput.setText(message);
            editText2.requestFocus();
            editText2.selectAll();
        }
    }

    public void newGame(){
        theNumber = (int)(Math.random() * 100 + 1);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText2 =  (EditText) findViewById(R.id.editText2);
        btnGuess =  (Button) findViewById(R.id.btnGuess);
        lblOutput =  (TextView) findViewById(R.id.lblOutput);

        newGame();
        btnGuess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkGuess();
            }
        });
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}


